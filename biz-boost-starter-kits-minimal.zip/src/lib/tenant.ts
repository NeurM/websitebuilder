import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
)

export interface Tenant {
  id: string
  name: string
  schema_name: string
  created_at: string
  updated_at: string
}

export async function getCurrentTenant(): Promise<Tenant | null> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const tenantId = user.user_metadata.tenant_id
  if (!tenantId) return null

  const { data: tenant, error } = await supabase
    .from('tenants')
    .select('*')
    .eq('id', tenantId)
    .single()

  if (error) {
    console.error('Error fetching tenant:', error)
    return null
  }

  return tenant
}

export async function setTenantContext(tenantId: string): Promise<boolean> {
  try {
    const { error } = await supabase.rpc('set_current_tenant', {
      tenant_id: tenantId
    })

    if (error) throw error
    return true
  } catch (error) {
    console.error('Error setting tenant context:', error)
    return false
  }
}

export async function createTenant(name: string): Promise<Tenant | null> {
  try {
    const { data: tenant, error } = await supabase
      .from('tenants')
      .insert([
        {
          name,
          schema_name: `tenant_${crypto.randomUUID()}`
        }
      ])
      .select()
      .single()

    if (error) throw error
    return tenant
  } catch (error) {
    console.error('Error creating tenant:', error)
    return null
  }
}

export async function updateUserTenant(userId: string, tenantId: string): Promise<boolean> {
  try {
    const { error } = await supabase.auth.admin.updateUserById(
      userId,
      { user_metadata: { tenant_id: tenantId } }
    )

    if (error) throw error
    return true
  } catch (error) {
    console.error('Error updating user tenant:', error)
    return false
  }
} 