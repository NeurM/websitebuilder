"""
ASGI config for website_builder project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""

import os
import django

# Set the Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'website_builder.settings')

# Initialize Django ASGI application early to ensure the app is loaded properly
django.setup()

from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from django_tenants.middleware.main import TenantMainMiddleware
from channels.security.websocket import AllowedHostsOriginValidator
from .routing import websocket_urlpatterns

# Get the Django ASGI application
django_asgi_app = get_asgi_application()

# Wrap the ASGI application with the tenant middleware
application = ProtocolTypeRouter({
    "http": TenantMainMiddleware(django_asgi_app),
    "websocket": AllowedHostsOriginValidator(
        AuthMiddlewareStack(
            TenantMainMiddleware(
                URLRouter(websocket_urlpatterns)
            )
        )
    ),
})
